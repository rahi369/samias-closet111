import React,{createContext,useContext,useEffect,useMemo,useState} from 'react';
import {onAuthStateChanged} from 'firebase/auth';
import {auth} from './firebase';
import {isAdmin} from './services/auth';
const C=createContext(null);
export function AppProvider({children}){
 const [user,setUser]=useState(null),[loading,setLoading]=useState(true),[bag,setBag]=useState(()=>JSON.parse(localStorage.getItem('sc_bag')||'[]'));
 useEffect(()=>onAuthStateChanged(auth,u=>{setUser(u);setLoading(false)}),[]);
 useEffect(()=>localStorage.setItem('sc_bag',JSON.stringify(bag)),[bag]);
 const add=(product,options={})=>setBag(b=>{const key=product.id+JSON.stringify(options);const old=b.find(x=>x.key===key);return old?b.map(x=>x.key===key?{...x,qty:x.qty+1}:x):[...b,{key,id:product.id,name:product.name,image:product.image,price:Number(product.price),qty:1,options}]});
 const remove=key=>setBag(b=>b.filter(x=>x.key!==key));
 const setQty=(key,qty)=>setBag(b=>qty<1?b.filter(x=>x.key!==key):b.map(x=>x.key===key?{...x,qty}:x));
 const clearOrdered=keys=>setBag(b=>b.filter(x=>!keys.includes(x.key)));
 const value=useMemo(()=>({user,loading,isAdmin:isAdmin(user),bag,add,remove,setQty,clearOrdered}),[user,loading,bag]);
 return <C.Provider value={value}>{children}</C.Provider>;
}
export const useApp=()=>useContext(C);
