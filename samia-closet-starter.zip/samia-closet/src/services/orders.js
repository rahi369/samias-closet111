import { addDoc, collection, getDocs, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, app } from '../firebase';
import { getFunctions } from 'firebase/functions';
export const functions=getFunctions(app);
export async function createOrder(order){
  const create= httpsCallable(functions,'createOrder');
  return (await create(order)).data;
}
export async function myOrders(uid){
  const q=query(collection(db,'orders'),where('userId','==',uid),orderBy('createdAt','desc')); const s=await getDocs(q); return s.docs.map(d=>({id:d.id,...d.data()}));
}
