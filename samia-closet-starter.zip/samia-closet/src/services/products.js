import { collection, addDoc, updateDoc, deleteDoc, doc, getDocs, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
export async function listProducts(){
  const q=query(collection(db,'products'),where('visible','==',true),orderBy('createdAt','desc'));
  const s=await getDocs(q); return s.docs.map(d=>({id:d.id,...d.data()}));
}
export async function adminProducts(){ const s=await getDocs(collection(db,'products')); return s.docs.map(d=>({id:d.id,...d.data()})); }
export async function createProduct(data){ return addDoc(collection(db,'products'),{...data,createdAt:serverTimestamp(),updatedAt:serverTimestamp()}); }
export async function updateProduct(id,data){ return updateDoc(doc(db,'products',id),{...data,updatedAt:serverTimestamp()}); }
export async function removeProduct(id){ return deleteDoc(doc(db,'products',id)); }
