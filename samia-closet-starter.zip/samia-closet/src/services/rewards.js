import { httpsCallable } from 'firebase/functions';
import { functions } from './orders';
export const submitQuiz=async(questionId,answerId)=> (await httpsCallable(functions,'submitQuiz')({questionId,answerId})).data;
export const openMysteryBox=async()=> (await httpsCallable(functions,'openMysteryBox')({})).data;
export const applyVouchers=async(voucherIds,orderId)=> (await httpsCallable(functions,'applyVouchers')({voucherIds,orderId})).data;
