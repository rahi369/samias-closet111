import { auth, googleProvider } from '../firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup, signOut, updateProfile } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

export const ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL;

async function ensureUserDoc(user, extra={}) {
  await setDoc(doc(db,'users',user.uid), {
    uid:user.uid, email:user.email || '', displayName:user.displayName || extra.displayName || '',
    updatedAt:serverTimestamp(), ...extra
  }, {merge:true});
}

export async function signup(name,email,password){
  const cred=await createUserWithEmailAndPassword(auth,email,password);
  if(name) await updateProfile(cred.user,{displayName:name});
  await ensureUserDoc(cred.user,{displayName:name||''});
  return cred.user;
}
export async function login(email,password){ const c=await signInWithEmailAndPassword(auth,email,password); await ensureUserDoc(c.user); return c.user; }
export async function googleLogin(){ const c=await signInWithPopup(auth,googleProvider); await ensureUserDoc(c.user); return c.user; }
export function logout(){ return signOut(auth); }
export function isAdmin(user){ return !!user && user.email?.toLowerCase()===ADMIN_EMAIL?.toLowerCase(); }
