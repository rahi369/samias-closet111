# SAMIA’S CLOSET — production architecture starter

This project is a clean React + Vite + Firebase architecture for the requested store.

## Before running
1. Copy `.env.example` to `.env`.
2. Fill `VITE_FIREBASE_API_KEY` from Firebase Console → Project settings → Web app config.
3. `npm install`
4. `npm run dev`

## Firebase
- Enable Email/Password and Google Authentication.
- Create Firestore.
- Deploy rules: `firebase deploy --only firestore:rules`
- Install functions dependencies: `cd functions && npm install`
- Deploy functions: `firebase deploy --only functions`

## Important production note
The UI and core callable backend are scaffolded, but voucher application, full admin order/customer/reward management, stock reservation, and deployment configuration still require the remaining production implementation and end-to-end Firebase testing. Do not treat this starter as fully production-ready until those tests pass.
