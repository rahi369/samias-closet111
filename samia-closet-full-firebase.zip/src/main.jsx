import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {onAuthStateChanged,signInWithPopup,signOut} from "firebase/auth";
import {collection,onSnapshot,query,orderBy} from "firebase/firestore";
import {auth,db,googleProvider} from "./firebase";
import "./styles.css";

const fallback=[
{id:"demo-w1",name:"Premium Women's Collection",category:"Women",price:450,description:"Add products from the Admin panel.",stock:10},
{id:"demo-b1",name:"Boys / Men's Collection",category:"Boys / Men",price:550,description:"Add products from the Admin panel.",stock:10}
];

function App(){
 const [user,setUser]=useState(null),[products,setProducts]=useState([]),[cart,setCart]=useState(()=>JSON.parse(localStorage.getItem("sc_cart")||"[]"));
 useEffect(()=>onAuthStateChanged(auth,setUser),[]);
 useEffect(()=>{const q=query(collection(db,"products"),orderBy("createdAt","desc"));return onSnapshot(q,s=>setProducts(s.docs.map(d=>({id:d.id,...d.data()}))),()=>setProducts([]))},[]);
 useEffect(()=>localStorage.setItem("sc_cart",JSON.stringify(cart)),[cart]);
 const list=products.length?products:fallback;
 const add=p=>setCart(c=>{const i=c.findIndex(x=>x.id===p.id);if(i>=0){let n=[...c];n[i]={...n[i],qty:n[i].qty+1};return n}return [...c,{...p,qty:1}]});
 const total=cart.reduce((s,p)=>s+p.price*p.qty,0);
 return <div>
  <header><a className="brand" href="/"><img src="/logo.jpg"/> <span>SAMIA’S CLOSET</span></a><nav><a href="#products">Products</a><a href="#rewards">Rewards</a><a href="#contact">Contact</a><a href="#cart">🛍️ Bag ({cart.reduce((s,p)=>s+p.qty,0)})</a><a href="#orders">📦 Orders</a></nav></header>
  <main>
   <section className="hero"><div><small>WOMEN • BOYS / MEN</small><h1>Everyday style,<br/><em>beautifully curated.</em></h1><p>Premium clothing with a clean, effortless shopping experience.</p><a className="btn" href="#products">Shop collection</a></div></section>
   <section id="products"><div className="sectionHead"><div><small>CURATED COLLECTION</small><h2>Shop the collection</h2></div></div><div className="grid">{list.map(p=><article className="card" key={p.id}><div className="pic">{p.imageUrl?<img src={p.imageUrl}/>:<span>{p.category}</span>}</div><small>{p.category}</small><h3>{p.name}</h3><strong>৳{p.price}</strong><p>{p.description||""}</p><button className="btn" onClick={()=>add(p)}>Add to Bag</button></article>)}</div></section>
   <section id="rewards" className="split"><div><small>REWARDS</small><h2>Shop, play, collect.</h2><p>Daily quiz, vouchers, streak rewards and mystery-box experiences will live here after Firebase reward collections are configured.</p></div><div className="rewardbox">🎁<b>Daily Quiz</b><span>Login to unlock rewards</span>{user?<button onClick={()=>alert("Rewards UI is ready for Firebase reward collections.")}>Open Rewards</button>:<button onClick={async()=>signInWithPopup(auth,googleProvider)}>Login with Google</button>}</div></section>
   <section id="cart" className="cart"><small>YOUR BAG</small><h2>Shopping bag</h2>{cart.length?<>{cart.map((p,i)=><div className="cartrow" key={p.id}><span>{p.name} × {p.qty}</span><b>৳{p.price*p.qty}</b><button onClick={()=>setCart(c=>c.filter((_,x)=>x!==i))}>Remove</button></div>)}<h3>Subtotal: ৳{total}</h3><button className="btn" onClick={()=>alert(user?"Checkout backend is next production integration step.":"Please sign in before checkout.")}>Checkout</button></>:<p>Your bag is empty.</p>}</section>
   <section id="orders" className="split"><div><small>ACCOUNT</small><h2>{user?"Signed in":"Customer account"}</h2><p>{user?user.email:"Sign in to access your account and order history."}</p>{user?<button onClick={()=>signOut(auth)}>Logout</button>:<button className="btn" onClick={()=>signInWithPopup(auth,googleProvider)}>Continue with Google</button>}</div><div><small>OWNER</small><h2>Direct Contact with Rahi</h2><p>Owner: Md. Humaun Husen Rahi</p><a className="btn" href="https://wa.me/8801834012069">WhatsApp</a></div></section>
   <section id="contact"><small>CONTACT</small><h2>Let's talk.</h2><p>WhatsApp: 01834012069</p><p><a href="https://www.facebook.com/share/1DxQzbBqLc/">Facebook</a> · <a href="https://www.instagram.com/shop.with.samia/">Instagram</a> · <a href="https://www.tiktok.com/@shop.with.samia">TikTok</a></p></section>
  </main><footer>SAMIA’S CLOSET · Owner: Md. Humaun Husen Rahi</footer>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);