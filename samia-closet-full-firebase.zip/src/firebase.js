import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, setPersistence, browserLocalPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyBH-yKICuT8UuHsfzkS4YxObspVq6RRtyE",
  authDomain: "samia-s-closet-new-8f9d0.firebaseapp.com",
  projectId: "samia-s-closet-new-8f9d0",
  storageBucket: "samia-s-closet-new-8f9d0.firebasestorage.app",
  messagingSenderId: "918050416914",
  appId: "1:918050416914:web:97448621af475b9c42ebcb"
};
const app=initializeApp(firebaseConfig);
export const auth=getAuth(app);
export const db=getFirestore(app);
export const storage=getStorage(app);
export const googleProvider=new GoogleAuthProvider();
setPersistence(auth,browserLocalPersistence).catch(console.error);
export default app;