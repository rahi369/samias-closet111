import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithRedirect, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged, signOut, setPersistence, browserLocalPersistence, EmailAuthProvider, linkWithCredential } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import { getFirestore, collection, getDocs, getDoc, doc, addDoc, setDoc, updateDoc, deleteDoc, query, orderBy, serverTimestamp, where } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";
import { firebaseConfig, ADMIN_EMAIL, STORE_DEFAULTS } from "./firebase-config.js";

export const app=initializeApp(firebaseConfig);
export const auth=getAuth(app);
setPersistence(auth,browserLocalPersistence).catch(()=>{});
export const db=getFirestore(app);
export const googleProvider=new GoogleAuthProvider();
googleProvider.setCustomParameters({prompt:"select_account"});

export function isAdminUser(user){return !!user?.email && user.email.toLowerCase()===ADMIN_EMAIL.toLowerCase()}
export async function adminLogin(){
  await setPersistence(auth,browserLocalPersistence);
  return signInWithRedirect(auth,googleProvider);
}
export async function adminLoginWithPassword(email,password){
  await setPersistence(auth,browserLocalPersistence);
  return signInWithEmailAndPassword(auth,email,password);
}
export async function customerSignUp(email,password){
  await setPersistence(auth,browserLocalPersistence);
  return createUserWithEmailAndPassword(auth,email,password);
}
export async function customerLogin(email,password){
  await setPersistence(auth,browserLocalPersistence);
  return signInWithEmailAndPassword(auth,email,password);
}
export async function customerLogout(){return signOut(auth)}
export async function finishAdminRedirect(){return auth.currentUser}
export function watchAuth(cb){return onAuthStateChanged(auth,cb)}
export async function adminLogout(){return signOut(auth)}
export async function listCombos(){const s=await getDocs(collection(db,"combos"));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function saveCombo(combo,id=null){const clean={...combo,updatedAt:serverTimestamp()};if(id)return updateDoc(doc(db,"combos",id),clean);clean.createdAt=serverTimestamp();return addDoc(collection(db,"combos"),clean)}
export async function removeCombo(id){return deleteDoc(doc(db,"combos",id))}
export async function getSettings(){const s=await getDoc(doc(db,"settings","site"));return s.exists()?{...STORE_DEFAULTS,...s.data()}:{...STORE_DEFAULTS}}
export async function saveSettings(data){return setDoc(doc(db,"settings","site"),{...data,updatedAt:serverTimestamp()},{merge:true})}
export async function listProducts(){const s=await getDocs(collection(db,"products"));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function saveProduct(product,id=null){const clean={...product,updatedAt:serverTimestamp()};if(id)return updateDoc(doc(db,"products",id),clean);clean.createdAt=serverTimestamp();return addDoc(collection(db,"products"),clean)}
export async function removeProduct(id){return deleteDoc(doc(db,"products",id))}
export async function listOrders(){const s=await getDocs(query(collection(db,"orders"),orderBy("createdAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listOwnOrders(uid){const s=await getDocs(query(collection(db,"orders"),where("userId","==",uid)));return s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>{const am=a.createdAt?.toMillis?a.createdAt.toMillis():0;const bm=b.createdAt?.toMillis?b.createdAt.toMillis():0;return bm-am})}
export async function createOrder(order){return addDoc(collection(db,"orders"),{...order,userId:auth.currentUser?.uid||null,status:"Pending",createdAt:serverTimestamp()})}
export async function trackEvent(event){return addDoc(collection(db,"visitorEvents"),{...event,createdAt:serverTimestamp()})}
export async function listVisitorEvents(){const s=await getDocs(query(collection(db,"visitorEvents"),orderBy("createdAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function updateOrder(id,status){return updateDoc(doc(db,"orders",id),{status,updatedAt:serverTimestamp()})}

export function getCurrentCustomer(){
  const u=auth.currentUser;
  return u && !u.isAnonymous && !isAdminUser(u) ? u : null;
}
export async function ensureCustomerAccount(){
  const u=getCurrentCustomer();
  if(!u) throw new Error("CUSTOMER_LOGIN_REQUIRED");
  return u;
}
export async function getRewardProfile(uid){const s=await getDoc(doc(db,"rewardProfiles",uid));return s.exists()?{id:s.id,...s.data()}:null}
export async function listOwnVouchers(uid){const s=await getDocs(query(collection(db,"vouchers"),where("userId","==",uid),orderBy("createdAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listOwnQuizHistory(uid){const s=await getDocs(query(collection(db,"quizHistory"),where("userId","==",uid)));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listQuizQuestions(){const s=await getDocs(collection(db,"quizQuestions"));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function saveQuizAttempt(id,data){return setDoc(doc(db,"quizAttempts",id),{...data,createdAt:serverTimestamp()},{merge:false})}
export async function saveQuizHistory(id,data){return setDoc(doc(db,"quizHistory",id),{...data,createdAt:serverTimestamp()},{merge:false})}
export async function saveRewardProfile(uid,data){return setDoc(doc(db,"rewardProfiles",uid),{...data,updatedAt:serverTimestamp()},{merge:true})}
export async function saveMysteryBox(id,data){return setDoc(doc(db,"mysteryBoxes",id),{...data,openedAt:serverTimestamp()},{merge:false})}
export async function saveVoucher(id,data){return setDoc(doc(db,"vouchers",id),{...data,createdAt:serverTimestamp()},{merge:false})}
export async function updateVoucher(id,data){return updateDoc(doc(db,"vouchers",id),{...data,updatedAt:serverTimestamp()})}
export async function listRewardCollection(name){const s=await getDocs(query(collection(db,name),orderBy("createdAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listRewardUsers(){const s=await getDocs(collection(db,"rewardProfiles"));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listQuizAttempts(){const s=await getDocs(query(collection(db,"quizAttempts"),orderBy("createdAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listMysteryBoxes(){const s=await getDocs(query(collection(db,"mysteryBoxes"),orderBy("openedAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function listVouchers(){const s=await getDocs(query(collection(db,"vouchers"),orderBy("createdAt","desc")));return s.docs.map(d=>({id:d.id,...d.data()}))}
export async function seedQuizQuestions(rows){for(const q of rows){await setDoc(doc(db,"quizQuestions",String(q.id)),q,{merge:true})}}

export async function removeQuizQuestion(id){return deleteDoc(doc(db,"quizQuestions",id))}
