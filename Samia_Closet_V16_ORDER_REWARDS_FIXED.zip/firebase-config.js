export const firebaseConfig={
 apiKey:"AIzaSyBH-yKICuT8UuHsfzkS4YxObspVq6RRtyE",
 authDomain:"samia-s-closet-new-8f9d0.firebaseapp.com",
 projectId:"samia-s-closet-new-8f9d0",
 storageBucket:"samia-s-closet-new-8f9d0.firebasestorage.app",
 messagingSenderId:"918050416914",
 appId:"1:918050416914:web:97448621af475b9c42ebcb"
};
export const ADMIN_EMAIL="rahihumaun369@gmail.com";
export const STORE_DEFAULTS={storeName:"Samia’s Closet",tagline:"Curated fashion. Beautifully simple.",heroTitle:"STYLE THAT FEELS LIKE YOU.",heroSubtitle:"A refined collection of fashion for everyday confidence — carefully selected, beautifully presented.",heroButton:"SHOP THE COLLECTION",ownerName:"Md.Humaun Husen Rahi",whatsapp:"01834012069",contactLabel:"DIRECT CONTACT WITH RAHI",facebook:"https://www.facebook.com/share/1DxQzbBqLc/",instagram:"https://www.instagram.com/shop.with.samia?stkn=MWVtem5jdzJoNnpyMw==",tiktok:"https://www.tiktok.com/@shop.with.samia?_r=1&_t=ZS-9A8d6CHf0a6",about:"Samia’s Closet brings together carefully selected fashion for different styles and collections, with an experience designed to feel refined from the first click to the final order.",deliveryText:"For product questions, orders or support, message us directly on WhatsApp.",dailyQuizReward:2,maxVouchersPerProduct:3,highVoucherMin:20,highVoucherMax:80,lowVoucherMaxUses:3,highVoucherMaxUses:1,quizRuleNote:"One quiz per visitor per day; each question is recorded permanently.",mysteryRuleNote:"One Mystery Box per visitor per week.",voucherExpiryDays:30};
